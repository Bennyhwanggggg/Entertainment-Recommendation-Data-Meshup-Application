let data = [
    '<tr>\
    <td><input type="checkbox" /></td>\
    <td>1</td>\
    <td><a href="#">Business management</a></td>\
<td>default</td>\
<td class="am-hide-sm-only">XXXXXX</td>\
    <td class="am-hide-sm-only">12.5.2018</td>\
<td>\
    </td>\
    </tr>',
    '2、the No.2',
    '3、the No.3',
    '4、the No.4',
    '5、the No.5',
    '6、the No.6',
    '7、the No.7',
    '8、the No.8',
    '9、the No.9',
    '10、the No.10',
    '11、the No.11',
    '12、the No.12',
    '13、the No.13',
    '14、the No.14',
    '15、the No.15',
    '16、the No.16',
    '17、the No.17',
    '18、the No.18',
    '19、the No.19',
    '20、the No.20',
    '21、the No.21',
    '22、the No.22',
    '23、the No.23',
    '24、the No.24',
    '25、the No.25',
    '26、the No.26',
    '27、the No.27',
    '28、the No.28',
    '29、the No.29',
    '30、the No.30'
];





let data1 = [
    '<tr>\
    <td><input type="checkbox" /></td>\
    <td>1</td>\
    <td><a href="#">Business management</a></td>\
<td>default</td>\
<td class="am-hide-sm-only">XXXXXX</td>\
    <td class="am-hide-sm-only">12.5.2018</td>\
<td>\
    </td>\
    </tr>',
    '2、the No.2',
    '3、the No.3',
    '4、the No.4',
    '5、the No.5',
    '6、the No.6',
    '7、the No.7',
    '8、the No.8',
    '9、the No.9',
    '10、the No.10',
    '11、the No.11',
    '12、the No.12',
    '13、the No.13',
    '14、the No.14',
    '15、the No.15',
    '16、the No.16',
    '17、the No.17',
    '18、the No.18',
    '19、the No.19',
    '20、the No.20',
    '21、the No.21',
    '22、the No.22',
    '23、the No.23',
    '24、the No.24',
    '25、the No.25',
    '26、the No.26',
    '27、the No.27',
    '28、the No.28',
    '29、the No.29',
    '30、the No.30'
];

let data2 = [
    '<tr>\
    <td><input type="checkbox" /></td>\
    <td>1</td>\
    <td><a href="#">Business management</a></td>\
<td>default</td>\
<td class="am-hide-sm-only">XXXXXX</td>\
    <td class="am-hide-sm-only">12.5.2018</td>\
<td>\
    </td>\
    </tr>',
    '2、the No.2',
    '3、the No.3',
    '4、the No.4',
    '5、the No.5',
    '6、the No.6',
    '7、the No.7',
    '8、the No.8',
    '9、the No.9',
    '10、the No.10',
    '11、the No.11',
    '12、the No.12',
    '13、the No.13',
    '14、the No.14',
    '15、the No.15',
    '16、the No.16',
    '17、the No.17',
    '18、the No.18',
    '19、the No.19',
    '20、the No.20',
    '21、the No.21',
    '22、the No.22',
    '23、the No.23',
    '24、the No.24',
    '25、the No.25',
    '26、the No.26',
    '27、the No.27',
    '28、the No.28',
    '29、the No.29',
    '30、the No.30'
];